<?php
// Telegram bot tokenini va ChatGPT API kalitini o'rnatamiz
$telegram_token = '7543213292:AAGr-YRmigN4C0dA-Z3vkoEGCcpEOIu8X-0';
$openai_api_key = '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';

// Telegramdan kelgan xabarlarni olish uchun funktsiya
function getTelegramUpdates($telegram_token) {
    $url = "https://api.telegram.org/bot$telegram_token/getUpdates";
    $response = file_get_contents($url);
    return json_decode($response, true);
}

// Telegramga javob yuborish uchun funktsiya
function sendTelegramMessage($telegram_token, $chat_id, $message) {
    $url = "https://api.telegram.org/bot$telegram_token/sendMessage";
    $data = [
        'chat_id' => $chat_id,
        'text' => $message
    ];
    file_get_contents($url . '?' . http_build_query($data));
}

// ChatGPT bilan integratsiya qilish uchun funktsiya
function getChatGPTResponse($openai_api_key, $user_message) {
    $url = "https://api.openai.com/v1/completions";
    $data = [
        'model' => 'text-davinci-003', // Model nomini o'zgartirishingiz mumkin
        'prompt' => $user_message,
        'max_tokens' => 100, // Javob uzunligini o'rnating
        'temperature' => 0.7
    ];
    
    $headers = [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $openai_api_key
    ];

    $options = [
        'http' => [
            'header' => $headers,
            'method' => 'POST',
            'content' => json_encode($data)
        ]
    ];

    $context = stream_context_create($options);
    $response = file_get_contents($url, false, $context);
    $response_data = json_decode($response, true);
    return $response_data['choices'][0]['text'];
}

// Kelgan xabarlarni tekshirish
$updates = getTelegramUpdates($telegram_token);
foreach ($updates['result'] as $update) {
    $chat_id = $update['message']['chat']['id'];
    $message_text = $update['message']['text'];

    // ChatGPT'dan javobni olish
    $chatgpt_response = getChatGPTResponse($openai_api_key, $message_text);

    // Javobni Telegramga yuborish
    sendTelegramMessage($telegram_token, $chat_id, $chatgpt_response);
}
?>