<?php
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// MySQL bilan ulanish
$conn = new mysqli("localhost", "jurabek", "Kamina_95", "x_u_15501_jurabek");

if ($conn->connect_error) {
    die("Ma'lumotlar bazasiga ulanishda xato: " . $conn->connect_error);
}

// Foydalanuvchi avvalgi javoblarini sessiyada saqlash
if (!isset($_SESSION['answered_questions'])) {
    $_SESSION['answered_questions'] = [];  // Bo'sh ro'yxat
}

// Avvalgi savollarni chiqarib tashlash
$answered_questions = $_SESSION['answered_questions'];
$placeholders = implode(',', array_fill(0, count($answered_questions), '?'));

// Keyingi savolni tanlash
$sql = "SELECT * FROM questions";
if (!empty($answered_questions)) {
    $sql .= " WHERE id NOT IN ($placeholders)";
}
$sql .= " LIMIT 1";

// Tayyorlangan so'rov
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die("SQL tayyorlashda xato: " . $conn->error);
}

// Raqamli indeksga ega qiymatlarni olish
$answered_questions_numeric = array_values($answered_questions);

// Savollar bo'yicha parametrlarni bog'lash
if (!empty($answered_questions_numeric)) {
    $types = str_repeat('i', count($answered_questions_numeric));
    $stmt->bind_param($types, ...$answered_questions_numeric);  // Raqamli indekslangan massivni foydalanamiz
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $question = $result->fetch_assoc(); // Savol olish
} else {
    // Agar savollar qolmagan bo'lsa, natijalar sahifasiga o'tish
    header("Location: result.php");
    exit();
}

// POST so'rovni qayta ishlash
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $question_id = $_POST['question_id'];
    $user_answer = $_POST['answer'];

    // Foydalanuvchi javobini sessiyada saqlash
    if (isset($user_answer)) {
        $_SESSION['answered_questions'][] = $question_id;
        if ($user_answer == $question['correct_answer']) {
            if (!isset($_SESSION['score'])) {
                $_SESSION['score'] = 0;
            }
            $_SESSION['score']++;  // To'g'ri javoblar uchun ball qo'shish
        }
    }

    // Keyingi savolga o'tish
    header("Location: quiz.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Test</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Quiz Test</h1>
    <form method="POST">
        <div class="question">
            <h3><?= $question['question_text'] ?></h3> <!-- Savol matnini chiqarish -->
            <label><input type="radio" name="answer" value="A" required> <?= $question['option_a'] ?></label><br>
            <label><input type="radio" name="answer" value="B"> <?= $question['option_b'] ?></label><br>
            <label><input type="radio" name="answer" value="C"> <?= $question['option_c'] ?></label><br>
            <label><input type="radio" name="answer" value="D"> <?= $question['option_d'] ?></label><br>
        </div>
        <input type="hidden" name="question_id" value="<?= $question['id'] ?>">
        <input type="submit" value="Keyingi savol" class="button">
    </form>
</body>
</html>

<?php
$conn->close(); // Ma'lumotlar bazasini yoping
?>
